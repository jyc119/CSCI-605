module ConcentrationGUI {
    requires transitive javafx.controls;
    exports connectfour.gui;
}