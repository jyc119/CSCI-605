/*
 * HW2: Dots and Boxes
 * Jordan Chin, jc9627@rit.edu
 * Charlie Leyens, cal3368@rit.edu
 */

package game;

/**
 * This class is an enumeration for representing the players in the Dots And
 * Boxes game.
 * <pre>
 * $ java DotsAndBoxes rows columns
 * Usage: java DotsAndBoxes rows columns
 *</pre>
 *
 * @author Jordan Chin, jc9627@rit.edu
 * @author Charlie Leyens, cal3368@rit.edu
 */
public enum Player {
    NONE, RED, BLUE;

    /**
     * Get the player's label.
     *
     * @return the string label
     */
    public String getLabel() {
        switch (this){
            case NONE:
                return " ";
            case RED:
                return "R";
            case BLUE:
                return "B";
        }
        return null;
    }
}
